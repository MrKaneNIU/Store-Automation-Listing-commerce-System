# Critical Source Excerpts

### 1. OCR draft creation

**backend/src/api/handlers/mall-api.ts:333-365**

```
 333 |   async createOcrBatch(request, context) {
 334 |     const input = parseCreateOcrBatchInput(request.body)
 335 |     const timestamp = context.now()
 336 |     const batch = await context.repository.saveBatch({
 337 |       id: context.createId('batch'),
 338 |       status: input.drafts.length > 0 ? 'recognized' : 'uploaded',
 339 |       imageUrls: input.imageUrls,
 340 |       createdAt: timestamp,
 341 |       updatedAt: timestamp,
 342 |     })
 343 |     const drafts = await context.repository.saveDrafts(
 344 |       input.drafts.map((draft) => ({
 345 |         id: context.createId('draft'),
 346 |         batchId: batch.id,
 347 |         ...draft,
 348 |         status: 'pending',
 349 |       })),
 350 |     )
 351 |     const job = await context.repository.saveOcrJob({
 352 |       id: `job-${batch.id}`,
 353 |       batchId: batch.id,
 354 |       status: 'queued',
 355 |       retryCount: 0,
 356 |       createdAt: timestamp,
 357 |       updatedAt: timestamp,
 358 |     })
 359 | 
 360 |     sendSuccess(request.response, 201, { batch, job, drafts })
 361 |   },
 362 | 
 363 |   async listOcrJobs(request, context) {
 364 |     sendSuccess(request.response, 200, { jobs: await context.repository.listOcrJobs(request.params.batchId) })
 365 |   },
```

**cloudfunctions/mallApi/mall-api-core.js:1525-1545**

```
1525 |   async createOcrBatch(event, context) {
1526 |     await requireAdminOrResolvedAnyRole(event, context, ['owner'], 'productManagement')
1527 |     const input = parseCreateOcrBatchInput(event.payload)
1528 |     const timestamp = context.now()
1529 |     const batch = await context.repository.saveBatch({
1530 |       id: context.createId('batch'),
1531 |       status: input.drafts.length > 0 ? 'recognized' : 'uploaded',
1532 |       imageUrls: input.imageUrls,
1533 |       imageAssetIds: input.imageAssetIds,
1534 |       createdAt: timestamp,
1535 |       updatedAt: timestamp,
1536 |     })
1537 |     const drafts = await context.repository.saveDrafts(input.drafts.map((draft) => ({
1538 |       id: context.createId('draft'),
1539 |       batchId: batch.id,
1540 |       ...draft,
1541 |       status: 'pending',
1542 |     })))
1543 |     const job = await context.repository.saveOcrJob({
1544 |       id: `job-${batch.id}`,
1545 |       batchId: batch.id,
```

### 2. Draft edit/delete/confirm

**backend/src/api/handlers/mall-api.ts:398-439**

```
 398 |   async updateDraft(request, context) {
 399 |     const patch = parseDraftPatchInput(request.body)
 400 |     const { draft, batchDrafts } = await findDraft(context.repository, request.params.draftId)
 401 |     const updatedDraft = { ...draft, ...patch }
 402 |     await context.repository.replaceDrafts(
 403 |       draft.batchId,
 404 |       batchDrafts.map((item) => (item.id === draft.id ? updatedDraft : item)),
 405 |     )
 406 | 
 407 |     sendSuccess(request.response, 200, { draft: updatedDraft })
 408 |   },
 409 | 
 410 |   async deleteDraft(request, context) {
 411 |     const { draft, batchDrafts } = await findDraft(context.repository, request.params.draftId)
 412 |     const deletedDraft = { ...draft, status: 'deleted' as const }
 413 |     await context.repository.replaceDrafts(
 414 |       draft.batchId,
 415 |       batchDrafts.map((item) => (item.id === draft.id ? deletedDraft : item)),
 416 |     )
 417 | 
 418 |     sendSuccess(request.response, 200, { draft: deletedDraft })
 419 |   },
 420 | 
 421 |   async confirmBatch(request, context) {
 422 |     const batch = (await context.repository.listBatches()).find((item) => item.id === request.params.batchId)
 423 |     if (!batch) {
 424 |       throw notFoundError('Batch not found')
 425 |     }
 426 |     if (batch.status === 'confirmed') {
 427 |       sendSuccess(request.response, 200, { issues: [], products: [], skus: [] })
 428 |       return
 429 |     }
 430 | 
 431 |     const currentDrafts = await context.repository.listDrafts(batch.id)
 432 |     const issues = currentDrafts
 433 |       .filter((draft) => draft.status !== 'deleted')
 434 |       .flatMap((draft) => validateDraftForConfirmation(draft).map((message) => ({ draftId: draft.id, message })))
 435 |     const confirmedDrafts = currentDrafts.map((draft) => {
 436 |       if (draft.status === 'deleted') return draft
 437 |       return { ...draft, status: issues.some((issue) => issue.draftId === draft.id) ? 'needs_completion' : 'confirmed' } as ProductDraft
 438 |     })
 439 |     await context.repository.replaceDrafts(batch.id, confirmedDrafts)
```

**cloudfunctions/mallApi/mall-api-core.js:1654-1687**

```
1654 |   async updateDraft(event, context) {
1655 |     await requireAdminOrResolvedAnyRole(event, context, ['owner'], 'productManagement')
1656 |     const patch = parseDraftPatchInput(event.payload)
1657 |     const { draft, batchDrafts } = await findDraft(context.repository, readString(event.params || {}, 'draftId'))
1658 |     const updatedDraft = { ...draft, ...patch }
1659 |     await context.repository.replaceDrafts(draft.batchId, batchDrafts.map((item) => (item.id === draft.id ? updatedDraft : item)))
1660 |     return { draft: updatedDraft }
1661 |   },
1662 |   async deleteDraft(event, context) {
1663 |     await requireAdminOrResolvedAnyRole(event, context, ['owner'], 'productManagement')
1664 |     const { draft, batchDrafts } = await findDraft(context.repository, readString(event.params || {}, 'draftId'))
1665 |     const deletedDraft = { ...draft, status: 'deleted' }
1666 |     await context.repository.replaceDrafts(draft.batchId, batchDrafts.map((item) => (item.id === draft.id ? deletedDraft : item)))
1667 |     return { draft: deletedDraft }
1668 |   },
1669 |   async confirmBatch(event, context) {
1670 |     await requireAdminOrResolvedAnyRole(event, context, ['owner'], 'productManagement')
1671 |     const batchId = readString(event.params || {}, 'batchId')
1672 |     const batch = (await context.repository.listBatches()).find((item) => item.id === batchId)
1673 |     if (!batch) throw notFoundError('Batch not found')
1674 |     if (batch.status === 'confirmed') return { issues: [], products: [], skus: [] }
1675 | 
1676 |     const currentDrafts = await context.repository.listDrafts(batch.id)
1677 |     const issues = currentDrafts
1678 |       .filter((draft) => draft.status !== 'deleted')
1679 |       .flatMap((draft) => validateDraftForConfirmation(draft).map((message) => ({ draftId: draft.id, message })))
1680 |     const confirmedDrafts = currentDrafts.map((draft) => {
1681 |       if (draft.status === 'deleted') return draft
1682 |       return { ...draft, status: issues.some((issue) => issue.draftId === draft.id) ? 'needs_completion' : 'confirmed' }
1683 |     })
1684 |     await context.repository.replaceDrafts(batch.id, confirmedDrafts)
1685 |     if (issues.length > 0) return { issues, products: [], skus: [] }
1686 | 
1687 |     const existingProducts = (await context.repository.listProducts()).filter((product) => product.createdFromBatchId === batch.id)
```

### 3. productCode to SPU

**src/domain/catalog/rules.ts:28-58**

```
  28 | const getSkuKey = (draft: ProductDraft) => `${draft.productCode}::${draft.spec}`
  29 | 
  30 | export const createProductsFromDrafts = (drafts: ProductDraft[]): CreateProductsResult => {
  31 |   const confirmedDrafts = drafts.filter((draft) => draft.status === 'confirmed')
  32 |   const productByCode = new Map<string, Product>()
  33 |   const skuByKey = new Map<string, Sku>()
  34 |   const priceByProductCode = new Map<string, number>()
  35 |   const warnings: ImportWarning[] = []
  36 | 
  37 |   confirmedDrafts.forEach((draft) => {
  38 |     const existingPrice = priceByProductCode.get(draft.productCode)
  39 |     if (existingPrice === undefined) {
  40 |       priceByProductCode.set(draft.productCode, draft.salePrice)
  41 |     } else if (existingPrice !== draft.salePrice) {
  42 |       warnings.push({
  43 |         type: 'price_conflict',
  44 |         productCode: draft.productCode,
  45 |         message: `${draft.productCode} 存在多个销售价，请复核。`,
  46 |       })
  47 |       priceByProductCode.set(draft.productCode, draft.salePrice)
  48 |     }
  49 | 
  50 |     let product = productByCode.get(draft.productCode)
  51 |     if (!product) {
  52 |       const timestamp = nowIso()
  53 |       product = {
  54 |         id: createId('product'),
  55 |         productCode: draft.productCode,
  56 |         productName: draft.productName,
  57 |         description: '',
  58 |         mainImageUrl: '',
```

### 4. productCode plus spec to SKU

**src/domain/catalog/rules.ts:58-86**

```
  58 |         mainImageUrl: '',
  59 |         imageUrls: [],
  60 |         status: 'pending_images',
  61 |         createdFromBatchId: draft.batchId,
  62 |         createdAt: timestamp,
  63 |         updatedAt: timestamp,
  64 |       }
  65 |       productByCode.set(draft.productCode, product)
  66 |     }
  67 | 
  68 |     const skuKey = getSkuKey(draft)
  69 |     const existingSku = skuByKey.get(skuKey)
  70 |     if (existingSku) {
  71 |       skuByKey.set(skuKey, {
  72 |         ...existingSku,
  73 |         salePrice: draft.salePrice,
  74 |         stock: existingSku.stock + draft.stock,
  75 |       })
  76 |       return
  77 |     }
  78 | 
  79 |     skuByKey.set(skuKey, {
  80 |       id: createId('sku'),
  81 |       productId: product.id,
  82 |       productCode: draft.productCode,
  83 |       spec: draft.spec,
  84 |       salePrice: draft.salePrice,
  85 |       stock: draft.stock,
  86 |     })
```

### 5. Duplicate SKU stock merge

**src/domain/catalog/rules.ts:66-80**

```
  66 |     }
  67 | 
  68 |     const skuKey = getSkuKey(draft)
  69 |     const existingSku = skuByKey.get(skuKey)
  70 |     if (existingSku) {
  71 |       skuByKey.set(skuKey, {
  72 |         ...existingSku,
  73 |         salePrice: draft.salePrice,
  74 |         stock: existingSku.stock + draft.stock,
  75 |       })
  76 |       return
  77 |     }
  78 | 
  79 |     skuByKey.set(skuKey, {
  80 |       id: createId('sku'),
```

**backend/src/api/handlers/mall-api.ts:304-317**

```
 304 |           updatedAt: context.now(),
 305 |         }
 306 |         productByCode.set(draft.productCode, product)
 307 |       }
 308 | 
 309 |       const skuKey = `${draft.productCode}::${draft.spec}`
 310 |       const existingSku = skuByKey.get(skuKey)
 311 |       if (existingSku) {
 312 |         skuByKey.set(skuKey, { ...existingSku, stock: existingSku.stock + draft.stock })
 313 |         return
 314 |       }
 315 | 
 316 |       skuByKey.set(skuKey, {
 317 |         id: context.createId('sku'),
```

### 6. Incomplete drafts cannot confirm

**src/domain/draft/rules.ts:10-44**

```
  10 | 
  11 | export const validateDrafts = (drafts: ProductDraft[]) => {
  12 |   const issues: DraftValidationIssue[] = []
  13 | 
  14 |   drafts
  15 |     .filter((draft) => draft.status !== 'deleted')
  16 |     .forEach((draft) => {
  17 |       if (!draft.productCode.trim()) {
  18 |         issues.push({ draftId: draft.id, field: 'productCode', message: 'productCode is required' })
  19 |       }
  20 |       if (!draft.productName.trim()) {
  21 |         issues.push({ draftId: draft.id, field: 'productName', message: 'productName is required' })
  22 |       }
  23 |       if (draft.salePrice <= 0) {
  24 |         issues.push({ draftId: draft.id, field: 'salePrice', message: 'salePrice must be greater than 0' })
  25 |       }
  26 |       if (!draft.spec.trim()) {
  27 |         issues.push({ draftId: draft.id, field: 'spec', message: 'spec is required' })
  28 |       }
  29 |       if (!isLowConfidenceDraftResolved(draft)) {
  30 |         issues.push({
  31 |           draftId: draft.id,
  32 |           field: 'confidence',
  33 |           message: 'Low-confidence OCR fields require manual correction or explicit acceptance before confirmation',
  34 |         })
  35 |       }
  36 |     })
  37 | 
  38 |   return issues
  39 | }
  40 | 
  41 | export const markDraftCompletion = (drafts: ProductDraft[]) => {
  42 |   const issueDraftIds = new Set(validateDrafts(drafts).map((issue) => issue.draftId))
  43 |   return drafts.map((draft) => {
  44 |     if (draft.status === 'deleted') {
```

### 7. Deleted drafts cannot create products

**src/domain/catalog/rules.ts:30-34**

```
  30 | export const createProductsFromDrafts = (drafts: ProductDraft[]): CreateProductsResult => {
  31 |   const confirmedDrafts = drafts.filter((draft) => draft.status === 'confirmed')
  32 |   const productByCode = new Map<string, Product>()
  33 |   const skuByKey = new Map<string, Sku>()
  34 |   const priceByProductCode = new Map<string, number>()
```

**src/domain/draft/rules.ts:46-62**

```
  46 |     }
  47 |     return issueDraftIds.has(draft.id) ? { ...draft, status: 'needs_completion' as const } : { ...draft, status: 'pending' as const }
  48 |   })
  49 | }
  50 | 
  51 | export const markDraftManualCorrection = (
  52 |   draft: ProductDraft,
  53 |   field: OcrDraftField,
  54 |   value: string | number,
  55 | ): ProductDraft => ({
  56 |   ...draft,
  57 |   [field]: value,
  58 |   correctionState: 'manual_corrected',
  59 | })
  60 | 
  61 | export const markDraftAccepted = (draft: ProductDraft): ProductDraft => ({
  62 |   ...draft,
```

### 8. Product without main image or SKU cannot publish

**src/domain/catalog/rules.ts:132-178**

```
 132 | export const canPublishProduct = (product: Product, skus: Sku[]) => {
 133 |   return validateProductForPublish(product, skus).canPublish
 134 | }
 135 | 
```

**backend/src/api/handlers/mall-api.ts:474-486**

```
 474 |   async publishProduct(request, context) {
 475 |     const product = await listProductOrThrow(context.repository, request.params.productId)
 476 |     const skus = await context.repository.listSkus(product.id)
 477 |     const publishMessages = validateProductForPublish(product, skus)
 478 |     if (publishMessages.length > 0) {
 479 |       throw conflictError(publishMessages[0])
 480 |     }
 481 | 
 482 |     const updated = await context.repository.updateProduct({
 483 |       ...product,
 484 |       status: 'published',
 485 |       updatedAt: context.now(),
 486 |     })
```

### 9. Customers see only published products

**backend/src/api/handlers/mall-api.ts:456-467**

```
 456 |   async listPublishedProducts(request, context) {
 457 |     const products = await context.repository.listProducts()
 458 |     const skus = await context.repository.listSkus()
 459 |     const publishedProducts = products.filter((product) => product.status === 'published' && validateProductForPublish(product, skus).length === 0)
 460 |     sendSuccess(request.response, 200, { products: publishedProducts })
 461 |   },
 462 | 
 463 |   async updateProductDescription(request, context) {
 464 |     const input = parseProductDescriptionInput(request.body)
 465 |     const product = await listProductOrThrow(context.repository, request.params.productId)
 466 |     const updated = await context.repository.updateProduct({
 467 |       ...product,
```

**cloudfunctions/mallApi/mall-api-core.js:1718-1735**

```
1718 |   async listPublishedProducts(_event, context) {
1719 |     const products = await context.repository.listProducts()
1720 |     const skus = await context.repository.listSkus()
1721 |     return {
1722 |       products: products.filter((product) => product.status === 'published' && validateProductForPublish(product, skus).length === 0),
1723 |     }
1724 |   },
1725 |   async listPublishedProductSummaries(_event, context) {
1726 |     const allProducts = await context.repository.listProducts()
1727 |     const skus = await context.repository.listSkus()
1728 |     const products = allProducts.filter((product) => product.status === 'published' && validateProductForPublish(product, skus).length === 0)
1729 | 
1730 |     return { products: products.map((product) => toPublishedProductSummary(product, skus)) }
1731 |   },
1732 |   async getPublishedProductDetail(event, context) {
1733 |     const productId = readString(event.params || {}, 'productId')
1734 |     const products = await context.repository.listProducts()
1735 |     const product = products.find((item) => item.id === productId) || null
```

### 10. Browsing without login

**src/features/cloudbase-mall/customer-product-list.ts:1-45**

```
   1 | import { getRuntimeCloudBaseMallApiClient } from '../../services/cloudbase/runtime-mall-api-client'
   2 | import type { CloudBaseMallApiClient } from '../../services/cloudbase/mall-api-client'
   3 | import { resolveProductImageUrls } from '../../services/storage/product-image-url'
   4 | import { uploadService } from '../../services/storage/runtime-upload-service'
   5 | import type { CustomerProductListViewModel } from '../customer-product-list/customer-product-list'
   6 | 
   7 | export const customerProductListLoadFailedMessage = '商品加载失败，请稍后重试'
   8 | 
   9 | export const getCloudBaseCustomerProductListView = async (
  10 |   client: CloudBaseMallApiClient = getRuntimeCloudBaseMallApiClient(),
  11 | ): Promise<CustomerProductListViewModel> => {
  12 |   try {
  13 |     const { products } = await client.listPublishedProductSummaries()
  14 |     const mainImageUrls = await resolveProductImageUrls(products.map((product) => product.mainImageUrl), uploadService)
  15 |     const renderableProducts = products.map((product, index) => ({
  16 |       ...product,
  17 |       mainImageUrl: mainImageUrls[index] ?? '',
  18 |       imageUrls: [],
  19 |     }))
  20 | 
  21 |     return {
  22 |       products: renderableProducts,
  23 |       emptyMessage: renderableProducts.length === 0 ? '暂无已上架商品' : '',
  24 |     }
  25 |   } catch {
  26 |     return {
  27 |       products: [],
  28 |       emptyMessage: customerProductListLoadFailedMessage,
  29 |     }
  30 |   }
  31 | }
  32 | 
```

**src/features/customer-product-list/customer-product-list.ts:1-45**

```
   1 | import type { Product } from '../../domain/catalog/types'
   2 | import { mallAccess } from '../mall-workflow/mall-access'
   3 | 
   4 | export type CustomerProductListItem = Product & {
   5 |   minPrice: number | '-'
   6 | }
   7 | 
   8 | export type CustomerProductListViewModel = {
   9 |   products: CustomerProductListItem[]
  10 |   emptyMessage: string
  11 | }
  12 | 
  13 | const toListItem = (product: Product): CustomerProductListItem => ({
  14 |   ...product,
  15 |   minPrice: mallAccess.getMinSkuPrice(product.id),
  16 | })
  17 | 
  18 | export const getCustomerProductListView = (): CustomerProductListViewModel => {
  19 |   const products = mallAccess.listPublishedProducts().map(toListItem)
  20 | 
  21 |   return {
  22 |     products,
  23 |     emptyMessage: products.length === 0 ? '暂无已上架商品' : '',
  24 |   }
  25 | }
  26 | 
```

### 11. Login/phone authorization only on order click

**src/pages/customer/product-detail/index.vue:392-433**

```
 392 | const confirmModal = (content: string) =>
 393 |   new Promise<boolean>((resolve) => {
 394 |     authPrompt.value = {
 395 |       content,
 396 |       resolve,
 397 |     }
 398 |   })
 399 | 
 400 | const resolveAuthPrompt = (value: boolean) => {
 401 |   const prompt = authPrompt.value
 402 |   authPrompt.value = null
 403 |   prompt?.resolve(value)
 404 | }
 405 | 
 406 | const requestPhoneCode = () =>
 407 |   new Promise<string | null>((resolve) => {
 408 |     phoneCodeRequest.value = { resolve }
 409 |   })
 410 | 
 411 | const resolvePhoneCode = (code: string | null) => {
 412 |   const request = phoneCodeRequest.value
 413 |   phoneCodeRequest.value = null
 414 |   request?.resolve(code)
 415 | }
 416 | 
 417 | const handlePhoneNumberAuthorization = (event: PhoneNumberAuthorizationEvent) => {
 418 |   const code = event.detail?.code
 419 |   resolvePhoneCode(code && code.trim() ? code : null)
 420 | }
 421 | 
 422 | const submitOrder = async () => {
 423 |   if (!viewModel.value.canSubmitOrder) {
 424 |     message.value = '请选择有库存的规格'
 425 |     return
 426 |   }
 427 | 
 428 |   const result = await submitCloudBaseCustomerProductDetailOrder({
 429 |     productId: productId.value,
 430 |     skuId: selectedSkuId.value,
 431 |     quantity: 1,
 432 |     authService: customerAuthService,
 433 |     confirmLogin: () => confirmModal('浏览商品不需要登录。只有你确认下单时，真实小程序才会触发微信快捷登录。'),
```

**src/features/cloudbase-mall/customer-product-detail.ts:1-90**

```
   1 | import type { Sku } from '../../domain/catalog/types'
   2 | import type { Order } from '../../domain/order/types'
   3 | import { mockWechatAuthService } from '../../services/auth/mock-wechat-auth-service'
   4 | import type { WechatAuthService } from '../../services/auth/wechat-auth-service'
   5 | import { getRuntimeCloudBaseMallApiClient } from '../../services/cloudbase/runtime-mall-api-client'
   6 | import type { CloudBaseMallApiClient } from '../../services/cloudbase/mall-api-client'
   7 | import { resolveProductImageFields } from '../../services/storage/product-image-url'
   8 | import { uploadService } from '../../services/storage/runtime-upload-service'
   9 | import type {
  10 |   CustomerProductDetailSkuView,
  11 |   CustomerProductDetailViewModel,
  12 |   SelectCustomerProductSkuResult,
  13 |   SubmitCustomerProductDetailOrderResult,
  14 | } from '../customer-product-detail/customer-product-detail'
  15 | import { productDescriptionFallbackText } from '../customer-product-detail/customer-product-detail'
  16 | 
  17 | const productUnavailableMessage = '商品不存在或未上架'
  18 | const selectAvailableSkuMessage = '请选择有库存的规格'
  19 | const outOfStockMessage = '该规格暂无库存'
  20 | const canceledAuthMessage = '已取消授权，未创建订单'
  21 | 
  22 | const toSkuView = (sku: Sku, selectedSkuId: string): CustomerProductDetailSkuView => ({
  23 |   id: sku.id,
  24 |   spec: sku.spec,
  25 |   salePrice: sku.salePrice,
  26 |   stock: sku.stock,
  27 |   isSelected: selectedSkuId === sku.id,
  28 |   isDisabled: sku.stock <= 0,
  29 | })
  30 | 
  31 | export const getCloudBaseCustomerProductDetailView = async (
  32 |   productId: string,
  33 |   selectedSkuId = '',
  34 |   client: CloudBaseMallApiClient = getRuntimeCloudBaseMallApiClient(),
  35 | ): Promise<CustomerProductDetailViewModel> => {
  36 |   const { product, skus: detailSkus } = await client.getPublishedProductDetail(productId)
  37 |   const renderableProduct = product ? await resolveProductImageFields(product, uploadService) : null
  38 |   const skus = product ? detailSkus.map((sku) => toSkuView(sku, selectedSkuId)) : []
  39 |   const selectedSku = skus.find((sku) => sku.id === selectedSkuId)
  40 | 
  41 |   return {
  42 |     product: renderableProduct,
  43 |     descriptionText: renderableProduct?.description.trim() ? renderableProduct.description : productDescriptionFallbackText,
  44 |     skus,
  45 |     isPublished: Boolean(product),
  46 |     canSubmitOrder: Boolean(product && selectedSku && !selectedSku.isDisabled),
  47 |     emptyMessage: productUnavailableMessage,
  48 |   }
  49 | }
  50 | 
  51 | export const selectCloudBaseCustomerProductSkuInView = (
  52 |   view: CustomerProductDetailViewModel,
  53 |   skuId: string,
  54 | ): SelectCustomerProductSkuResult & { view: CustomerProductDetailViewModel } => {
  55 |   const sku = view.skus.find((item) => item.id === skuId)
  56 | 
  57 |   if (!view.product || !view.isPublished) {
  58 |     return { selectedSkuId: '', message: productUnavailableMessage, view }
  59 |   }
  60 |   if (!sku) {
  61 |     return { selectedSkuId: '', message: outOfStockMessage, view }
  62 |   }
  63 | 
  64 |   const skus = view.skus.map((item) => ({
  65 |     ...item,
  66 |     isSelected: item.id === sku.id,
  67 |   }))
  68 |   const nextView = {
  69 |     ...view,
  70 |     skus,
  71 |     canSubmitOrder: !sku.isDisabled,
  72 |   }
  73 | 
  74 |   return {
  75 |     selectedSkuId: sku.id,
  76 |     message: sku.isDisabled ? outOfStockMessage : '',
  77 |     view: nextView,
  78 |   }
  79 | }
  80 | 
  81 | export const selectCloudBaseCustomerProductSku = async (
  82 |   productId: string,
  83 |   skuId: string,
  84 |   client: CloudBaseMallApiClient = getRuntimeCloudBaseMallApiClient(),
  85 | ): Promise<SelectCustomerProductSkuResult> => {
  86 |   const view = await getCloudBaseCustomerProductDetailView(productId, skuId, client)
  87 |   const result = selectCloudBaseCustomerProductSkuInView(view, skuId)
  88 |   return { selectedSkuId: result.selectedSkuId, message: result.message }
  89 | }
  90 | 
```

### 12. Cancelled authorization creates no order and reserves no stock

**src/pages/customer/product-detail/index.vue:406-433**

```
 406 | const requestPhoneCode = () =>
 407 |   new Promise<string | null>((resolve) => {
 408 |     phoneCodeRequest.value = { resolve }
 409 |   })
 410 | 
 411 | const resolvePhoneCode = (code: string | null) => {
 412 |   const request = phoneCodeRequest.value
 413 |   phoneCodeRequest.value = null
 414 |   request?.resolve(code)
 415 | }
 416 | 
 417 | const handlePhoneNumberAuthorization = (event: PhoneNumberAuthorizationEvent) => {
 418 |   const code = event.detail?.code
 419 |   resolvePhoneCode(code && code.trim() ? code : null)
 420 | }
 421 | 
 422 | const submitOrder = async () => {
 423 |   if (!viewModel.value.canSubmitOrder) {
 424 |     message.value = '请选择有库存的规格'
 425 |     return
 426 |   }
 427 | 
 428 |   const result = await submitCloudBaseCustomerProductDetailOrder({
 429 |     productId: productId.value,
 430 |     skuId: selectedSkuId.value,
 431 |     quantity: 1,
 432 |     authService: customerAuthService,
 433 |     confirmLogin: () => confirmModal('浏览商品不需要登录。只有你确认下单时，真实小程序才会触发微信快捷登录。'),
```

**src/features/cloudbase-mall/customer-product-detail.ts:90-150**

```
  90 | 
  91 | export const submitCloudBaseCustomerProductDetailOrder = async (params: {
  92 |   productId: string
  93 |   skuId: string
  94 |   quantity?: number
  95 |   authService?: WechatAuthService
  96 |   confirmLogin: () => Promise<boolean>
  97 |   confirmPhoneAuthorization: () => Promise<boolean>
  98 |   requestPhoneNumber?: () => Promise<string | null>
  99 |   client?: CloudBaseMallApiClient
 100 | }): Promise<SubmitCustomerProductDetailOrderResult> => {
 101 |   const client = params.client ?? getRuntimeCloudBaseMallApiClient()
 102 |   const view = await getCloudBaseCustomerProductDetailView(params.productId, params.skuId, client)
 103 |   const sku = view.skus.find((item) => item.id === params.skuId)
 104 | 
 105 |   if (!view.product || !view.isPublished) {
 106 |     return { status: 'blocked', order: null, message: productUnavailableMessage }
 107 |   }
 108 |   if (!sku || sku.isDisabled) {
 109 |     return { status: 'blocked', order: null, message: selectAvailableSkuMessage }
 110 |   }
 111 | 
 112 |   const authService = params.authService ?? mockWechatAuthService
 113 |   let session = authService.getCurrentSession()
 114 |   if (!session) {
 115 |     const shouldLogin = await params.confirmLogin()
 116 |     if (!shouldLogin) {
 117 |       return { status: 'canceled', order: null, message: canceledAuthMessage }
 118 |     }
 119 |     session = await authService.login()
 120 |   }
 121 | 
 122 |   if (!session.phoneNumber) {
 123 |     const shouldAuthorizePhone = await params.confirmPhoneAuthorization()
 124 |     if (!shouldAuthorizePhone) {
 125 |       return { status: 'canceled', order: null, message: canceledAuthMessage }
 126 |     }
 127 |     const phoneNumber = params.requestPhoneNumber ? await params.requestPhoneNumber() : undefined
 128 |     const authorizedSession = await authService.authorizePhoneNumber(phoneNumber ?? undefined)
 129 |     if (!authorizedSession) {
 130 |       return { status: 'canceled', order: null, message: canceledAuthMessage }
 131 |     }
 132 |     session = authorizedSession
 133 |   }
 134 | 
 135 |   if (!session?.phoneNumber) {
 136 |     return { status: 'canceled', order: null, message: canceledAuthMessage }
 137 |   }
 138 | 
 139 |   try {
 140 |     const { order } = await client.createCustomerOrder({
 141 |       productId: view.product.id,
 142 |       skuId: sku.id,
 143 |       quantity: params.quantity ?? 1,
 144 |       session,
 145 |     })
 146 | 
 147 |     return {
 148 |       status: 'created',
 149 |       order: order as Order,
 150 |       message: `订单已提交，等待商家确认：${order.id}`,
```

### 13. Order reserves stock

**backend/src/api/handlers/mall-api.ts:535-590**

```
 535 |       }
 536 |     }
 537 | 
 538 |     sendSuccess(request.response, 200, { skus: updatedSkus })
 539 |   },
 540 | 
 541 |   async listPendingImageTasks(request, context) {
 542 |     const products = (await context.repository.listProducts()).filter((product) => product.status === 'pending_images')
 543 |     sendSuccess(request.response, 200, { products })
 544 |   },
 545 | 
 546 |   async supplementProductImages(request, context) {
 547 |     const input = parseSupplementImagesInput(request.body)
 548 |     const product = await listProductOrThrow(context.repository, request.params.productId)
 549 |     const updated = await context.repository.updateProduct({
 550 |       ...product,
 551 |       mainImageUrl: input.mainImageUrl,
 552 |       imageUrls: input.imageUrls,
 553 |       status: 'ready_to_publish',
 554 |       updatedAt: context.now(),
 555 |     })
 556 |     sendSuccess(request.response, 200, { product: updated })
 557 |   },
 558 | 
 559 |   async createCustomerOrder(request, context) {
 560 |     const input = parseCustomerOrderInput(request.body)
 561 |     if (!input.session.phoneNumber) {
 562 |       throw unauthorizedError('Wechat phone authorization is required before ordering')
 563 |     }
 564 | 
 565 |     const product = await listProductOrThrow(context.repository, input.productId)
 566 |     const sku = (await context.repository.listSkus(product.id)).find((item) => item.id === input.skuId)
 567 |     if (!sku) {
 568 |       throw notFoundError('SKU not found')
 569 |     }
 570 |     if (product.status !== 'published' || sku.stock < input.quantity) {
 571 |       throw conflictError('Product is unpublished or stock is insufficient')
 572 |     }
 573 | 
 574 |     const timestamp = context.now()
 575 |     const order: Order = {
 576 |       id: context.createId('order'),
 577 |       customerName: input.session.nickname ?? 'Wechat Customer',
 578 |       customerPhone: input.session.phoneNumber,
 579 |       customerId: input.session.customerId,
 580 |       customerAuthSource: input.session.authSource ?? 'mock_wechat',
 581 |       status: 'pending_merchant_confirm',
 582 |       items: [
 583 |         {
 584 |           skuId: sku.id,
 585 |           productId: product.id,
 586 |           productName: product.productName,
 587 |           productCode: product.productCode,
 588 |           spec: sku.spec,
 589 |           salePrice: sku.salePrice,
 590 |           quantity: input.quantity,
```

**src/domain/order/rules.ts:1-26**

```
   1 | import type { Product } from '../catalog/types'
   2 | import type { Sku } from '../catalog/types'
   3 | import { createId, nowIso } from '../shared/ids'
   4 | import type { Order, OrderItem } from './types'
   5 | 
   6 | export const canCreateOrder = (product: Product, sku: Sku, quantity: number) => {
   7 |   return product.status === 'published' && sku.stock >= quantity && quantity > 0
   8 | }
   9 | 
  10 | export const createPendingOrder = (params: {
  11 |   product: Product
  12 |   sku: Sku
  13 |   quantity: number
  14 |   customerName: string
  15 |   customerPhone: string
  16 |   customerId?: string
  17 |   customerAuthSource?: 'mock_wechat' | 'wechat'
  18 |   idempotencyKey?: string
  19 | }): Order => {
  20 |   const item: OrderItem = {
  21 |     skuId: params.sku.id,
  22 |     productId: params.product.id,
  23 |     productName: params.product.productName,
  24 |     productCode: params.product.productCode,
  25 |     spec: params.sku.spec,
  26 |     salePrice: params.sku.salePrice,
```

### 14. Oversell prevention

**src/domain/order/rules.ts:1-26**

```
   1 | import type { Product } from '../catalog/types'
   2 | import type { Sku } from '../catalog/types'
   3 | import { createId, nowIso } from '../shared/ids'
   4 | import type { Order, OrderItem } from './types'
   5 | 
   6 | export const canCreateOrder = (product: Product, sku: Sku, quantity: number) => {
   7 |   return product.status === 'published' && sku.stock >= quantity && quantity > 0
   8 | }
   9 | 
  10 | export const createPendingOrder = (params: {
  11 |   product: Product
  12 |   sku: Sku
  13 |   quantity: number
  14 |   customerName: string
  15 |   customerPhone: string
  16 |   customerId?: string
  17 |   customerAuthSource?: 'mock_wechat' | 'wechat'
  18 |   idempotencyKey?: string
  19 | }): Order => {
  20 |   const item: OrderItem = {
  21 |     skuId: params.sku.id,
  22 |     productId: params.product.id,
  23 |     productName: params.product.productName,
  24 |     productCode: params.product.productCode,
  25 |     spec: params.sku.spec,
  26 |     salePrice: params.sku.salePrice,
```

**backend/src/api/handlers/mall-api.ts:550-572**

```
 550 |       ...product,
 551 |       mainImageUrl: input.mainImageUrl,
 552 |       imageUrls: input.imageUrls,
 553 |       status: 'ready_to_publish',
 554 |       updatedAt: context.now(),
 555 |     })
 556 |     sendSuccess(request.response, 200, { product: updated })
 557 |   },
 558 | 
 559 |   async createCustomerOrder(request, context) {
 560 |     const input = parseCustomerOrderInput(request.body)
 561 |     if (!input.session.phoneNumber) {
 562 |       throw unauthorizedError('Wechat phone authorization is required before ordering')
 563 |     }
 564 | 
 565 |     const product = await listProductOrThrow(context.repository, input.productId)
 566 |     const sku = (await context.repository.listSkus(product.id)).find((item) => item.id === input.skuId)
 567 |     if (!sku) {
 568 |       throw notFoundError('SKU not found')
 569 |     }
 570 |     if (product.status !== 'published' || sku.stock < input.quantity) {
 571 |       throw conflictError('Product is unpublished or stock is insufficient')
 572 |     }
```

### 15. Order confirmation

**backend/src/api/handlers/mall-api.ts:611-620**

```
 611 |   async confirmMerchantOrder(request, context) {
 612 |     const order = await listOrderOrThrow(context.repository, request.params.orderId)
 613 |     if (order.status !== 'pending_merchant_confirm') {
 614 |       throw conflictError('Only pending merchant-confirmation orders can be confirmed')
 615 |     }
 616 | 
 617 |     const updated = await context.repository.updateOrder({ ...order, status: 'confirmed', updatedAt: context.now() })
 618 |     sendSuccess(request.response, 200, { order: updated })
 619 |   },
 620 | 
```

**cloudfunctions/mallApi/mall-api-core.js:1936-1955**

```
1936 |   async confirmMerchantOrder(event, context) {
1937 |     await requireAdminOrResolvedAnyRole(event, context, ['owner'], 'orderConfirmation')
1938 |     const order = await findOrder(context.repository, readString(event.params || {}, 'orderId'))
1939 |     if (order.status !== 'pending_merchant_confirm') {
1940 |       throw conflictError('Only pending merchant-confirmation orders can be confirmed')
1941 |     }
1942 |     const updatedAt = context.now()
1943 |     const confirmed = await context.repository.updateOrder({ ...order, status: 'confirmed', updatedAt })
1944 |     await context.repository.saveInventoryLedgerEntry({
1945 |       id: context.createId('ledger'),
1946 |       skuId: order.items[0].skuId,
1947 |       orderId: order.id,
1948 |       action: 'confirm',
1949 |       quantityDelta: 0,
1950 |       sourceType: 'order',
1951 |       sourceId: order.id,
1952 |       note: `confirm order ${order.id}`,
1953 |       createdAt: updatedAt,
1954 |     })
1955 |     return { order: confirmed }
```

### 16. Order cancellation

**backend/src/api/handlers/mall-api.ts:621-639**

```
 621 |   async cancelMerchantOrder(request, context) {
 622 |     const order = await listOrderOrThrow(context.repository, request.params.orderId)
 623 |     if (order.status !== 'pending_merchant_confirm') {
 624 |       throw conflictError('Only pending merchant-confirmation orders can be canceled')
 625 |     }
 626 | 
 627 |     for (const item of order.items) {
 628 |       const sku = (await context.repository.listSkus()).find((currentSku) => currentSku.id === item.skuId)
 629 |       if (sku) {
 630 |         await context.repository.updateSku({ ...sku, stock: sku.stock + item.quantity })
 631 |       }
 632 |     }
 633 | 
 634 |     const updated = await context.repository.updateOrder({ ...order, status: 'canceled', updatedAt: context.now() })
 635 |     sendSuccess(request.response, 200, { order: updated })
 636 |   },
 637 | }
 638 | 
 639 | export const methodNotAllowed = (response: Parameters<typeof sendJson>[0]): void => {
```

**cloudfunctions/mallApi/mall-api-core.js:1957-1974**

```
1957 |   async cancelMerchantOrder(event, context) {
1958 |     await requireAdminOrResolvedAnyRole(event, context, ['owner'], 'orderConfirmation')
1959 |     const order = await findOrder(context.repository, readString(event.params || {}, 'orderId'))
1960 |     if (order.status !== 'pending_merchant_confirm') {
1961 |       throw conflictError('Only pending merchant-confirmation orders can be canceled')
1962 |     }
1963 |     const updatedAt = context.now()
1964 |     for (const item of order.items) {
1965 |       const sku = (await context.repository.listSkus()).find((currentSku) => currentSku.id === item.skuId)
1966 |       if (sku) {
1967 |         await context.repository.updateSku({ ...sku, stock: sku.stock + item.quantity })
1968 |         await context.repository.saveInventoryLedgerEntry({
1969 |           id: context.createId('ledger'),
1970 |           skuId: sku.id,
1971 |           orderId: order.id,
1972 |           action: 'release',
1973 |           quantityDelta: item.quantity,
1974 |           sourceType: 'order',
```

### 17. Cancel pending order releases stock

**backend/src/api/handlers/mall-api.ts:621-639**

```
 621 |   async cancelMerchantOrder(request, context) {
 622 |     const order = await listOrderOrThrow(context.repository, request.params.orderId)
 623 |     if (order.status !== 'pending_merchant_confirm') {
 624 |       throw conflictError('Only pending merchant-confirmation orders can be canceled')
 625 |     }
 626 | 
 627 |     for (const item of order.items) {
 628 |       const sku = (await context.repository.listSkus()).find((currentSku) => currentSku.id === item.skuId)
 629 |       if (sku) {
 630 |         await context.repository.updateSku({ ...sku, stock: sku.stock + item.quantity })
 631 |       }
 632 |     }
 633 | 
 634 |     const updated = await context.repository.updateOrder({ ...order, status: 'canceled', updatedAt: context.now() })
 635 |     sendSuccess(request.response, 200, { order: updated })
 636 |   },
 637 | }
 638 | 
 639 | export const methodNotAllowed = (response: Parameters<typeof sendJson>[0]): void => {
```

**cloudfunctions/mallApi/mall-api-core.js:1957-1974**

```
1957 |   async cancelMerchantOrder(event, context) {
1958 |     await requireAdminOrResolvedAnyRole(event, context, ['owner'], 'orderConfirmation')
1959 |     const order = await findOrder(context.repository, readString(event.params || {}, 'orderId'))
1960 |     if (order.status !== 'pending_merchant_confirm') {
1961 |       throw conflictError('Only pending merchant-confirmation orders can be canceled')
1962 |     }
1963 |     const updatedAt = context.now()
1964 |     for (const item of order.items) {
1965 |       const sku = (await context.repository.listSkus()).find((currentSku) => currentSku.id === item.skuId)
1966 |       if (sku) {
1967 |         await context.repository.updateSku({ ...sku, stock: sku.stock + item.quantity })
1968 |         await context.repository.saveInventoryLedgerEntry({
1969 |           id: context.createId('ledger'),
1970 |           skuId: sku.id,
1971 |           orderId: order.id,
1972 |           action: 'release',
1973 |           quantityDelta: item.quantity,
1974 |           sourceType: 'order',
```

### 18. Confirmed order cannot be canceled

**src/domain/order/rules.ts:28-48**

```
  28 |   }
  29 |   const timestamp = nowIso()
  30 | 
  31 |   return {
  32 |     id: createId('order'),
  33 |     customerName: params.customerName,
  34 |     customerPhone: params.customerPhone,
  35 |     customerId: params.customerId,
  36 |     customerAuthSource: params.customerAuthSource,
  37 |     idempotencyKey: params.idempotencyKey,
  38 |     status: 'pending_merchant_confirm',
  39 |     items: [item],
  40 |     totalAmount: item.salePrice * item.quantity,
  41 |     createdAt: timestamp,
  42 |     updatedAt: timestamp,
  43 |   }
  44 | }
  45 | 
  46 | export const confirmOrder = (order: Order): Order => ({
  47 |   ...order,
  48 |   status: 'confirmed',
```

**backend/src/api/handlers/mall-api.ts:621-632**

```
 621 |   async cancelMerchantOrder(request, context) {
 622 |     const order = await listOrderOrThrow(context.repository, request.params.orderId)
 623 |     if (order.status !== 'pending_merchant_confirm') {
 624 |       throw conflictError('Only pending merchant-confirmation orders can be canceled')
 625 |     }
 626 | 
 627 |     for (const item of order.items) {
 628 |       const sku = (await context.repository.listSkus()).find((currentSku) => currentSku.id === item.skuId)
 629 |       if (sku) {
 630 |         await context.repository.updateSku({ ...sku, stock: sku.stock + item.quantity })
 631 |       }
 632 |     }
```

### 19. Owner/staff/customer permission checks

**cloudfunctions/mallApi/mall-api-core.js:410-456**

```
 410 | const requireAdminOrResolvedAnyRole = async (event, context, roles, permission) => {
 411 |   const adminSession = normalizeAdminSession(event.adminSession)
 412 |   if (adminSession) {
 413 |     if (!hasAdminPermission(adminSession, permission)) throw forbiddenError('Permission denied')
 414 |     return adminSession
 415 |   }
 416 |   return requireResolvedAnyRole(event, context, roles)
 417 | }
 418 | 
 419 | const createIdFactory = () => {
 420 |   let counter = Number(process.env.MALL_API_ID_SEED || 0)
 421 |   return (prefix) => `${prefix}-${Date.now().toString(36)}-${++counter}`
 422 | }
 423 | 
 424 | const toBatchDocument = (batch) => ({
 425 |   _id: batch.id,
 426 |   status: batch.status,
 427 |   image_urls: batch.imageUrls,
 428 |   ...(Array.isArray(batch.imageAssetIds) ? { image_asset_ids: batch.imageAssetIds } : {}),
 429 |   created_at: batch.createdAt,
 430 |   updated_at: batch.updatedAt,
 431 | })
 432 | 
 433 | const toBatch = (document) => ({
 434 |   id: document._id,
 435 |   status: document.status,
 436 |   imageUrls: document.image_urls,
 437 |   ...(Array.isArray(document.image_asset_ids) ? { imageAssetIds: document.image_asset_ids } : {}),
 438 |   createdAt: document.created_at,
 439 |   updatedAt: document.updated_at,
 440 | })
 441 | 
 442 | const toOcrJobDocument = (job) => ({
 443 |   _id: job.id,
 444 |   batch_id: job.batchId,
 445 |   status: job.status,
 446 |   ...(job.failureReason ? { failure_reason: job.failureReason } : {}),
 447 |   retry_count: job.retryCount,
 448 |   created_at: job.createdAt,
 449 |   updated_at: job.updatedAt,
 450 | })
 451 | 
 452 | const toOcrJob = (document) => ({
 453 |   id: document._id,
 454 |   batchId: document.batch_id,
 455 |   status: document.status,
 456 |   ...(document.failure_reason ? { failureReason: document.failure_reason } : {}),
```

**src/features/admin-permissions/admin-permissions.ts:1-75**

```
   1 | import { nowIso } from '../../domain/shared/ids'
   2 | 
   3 | export type AdminRole = 'creator' | 'owner' | 'staff'
   4 | 
   5 | export type AdminPermissionScope =
   6 |   | 'workbenchAccess'
   7 |   | 'productManagement'
   8 |   | 'orderConfirmation'
   9 |   | 'more'
  10 |   | 'homepageSettings'
  11 |   | 'accountManagement'
  12 |   | 'permissionManagement'
  13 | 
  14 | export type AdminAccountStatus = 'active' | 'disabled'
  15 | 
  16 | export type AdminAccount = {
  17 |   account: string
  18 |   role: AdminRole
  19 |   roleLabel: string
  20 |   permissions: AdminPermissionScope[]
  21 |   permissionLabels: string[]
  22 |   status: AdminAccountStatus
  23 |   statusLabel: string
  24 |   createdAt: string
  25 |   updatedAt: string
  26 | }
  27 | 
  28 | export type AdminPermissionAuditLog = {
  29 |   id: string
  30 |   operatorAccount: string
  31 |   targetAccount: string
  32 |   action: 'authorize' | 'disable'
  33 |   actionLabel: string
  34 |   role?: AdminRole
  35 |   roleLabel?: string
  36 |   permissions: AdminPermissionScope[]
  37 |   permissionLabels: string[]
  38 |   createdAt: string
  39 | }
  40 | 
  41 | export type AdminPermissionView = {
  42 |   currentAccount: AdminAccount | null
  43 |   accounts: AdminAccount[]
  44 |   auditLogs: AdminPermissionAuditLog[]
  45 |   scopeOptions: Array<{
  46 |     label: string
  47 |     value: AdminPermissionScope
  48 |   }>
  49 |   canGrantOwner: boolean
  50 | }
  51 | 
  52 | export type AdminPermissionCommandResult = {
  53 |   status: 'success' | 'failed'
  54 |   message: string
  55 | }
  56 | 
  57 | const allPermissionScopes: AdminPermissionScope[] = [
  58 |   'workbenchAccess',
  59 |   'productManagement',
  60 |   'orderConfirmation',
  61 |   'more',
  62 |   'homepageSettings',
  63 |   'accountManagement',
  64 |   'permissionManagement',
  65 | ]
  66 | 
  67 | const scopeOptions: AdminPermissionView['scopeOptions'] = [
  68 |   { label: '工作台进入权限', value: 'workbenchAccess' },
  69 |   { label: '商品管理', value: 'productManagement' },
  70 |   { label: '订单确认', value: 'orderConfirmation' },
  71 |   { label: '更多', value: 'more' },
  72 |   { label: '首页设置', value: 'homepageSettings' },
  73 |   { label: '账号管理', value: 'accountManagement' },
  74 |   { label: '权限管理', value: 'permissionManagement' },
  75 | ]
```

### 20. mock/real/CloudBase service switch points

**src/services/cloudbase/runtime-mall-api-client.ts:1-80**

```
   1 | import { createCloudBaseFunctionClient } from './cloudbase-function-client'
   2 | import { createCloudBaseMallApiClient, type CloudBaseMallApiClient } from './mall-api-client'
   3 | 
   4 | type WxCloudRuntime = {
   5 |   init?: (options: { env: string }) => void
   6 |   callFunction: (request: { name: string; data: unknown }) => Promise<{ result: unknown }>
   7 | }
   8 | 
   9 | declare const wx: { cloud?: WxCloudRuntime } | undefined
  10 | 
  11 | const cloudBaseEnvId = '[REDACTED_CLOUDBASE_ENV]'
  12 | 
  13 | let initialized = false
  14 | let client: CloudBaseMallApiClient | null = null
  15 | 
  16 | const getErrorMessage = (error: unknown): string => {
  17 |   if (error instanceof Error) {
  18 |     return error.message
  19 |   }
  20 | 
  21 |   return String(error)
  22 | }
  23 | 
  24 | export const createRuntimeCloudBaseError = (error: unknown, envId = cloudBaseEnvId): Error => {
  25 |   const message = getErrorMessage(error)
  26 | 
  27 |   if (message.includes('-501000') || message.includes('Environment not found') || message.includes('INVALID_ENV')) {
  28 |     return new Error(
  29 |       `CloudBase environment not found for current mini-program AppID. Runtime env: ${envId}. Open WeChat DevTools Cloud panel, confirm this AppID can access the same env, then rebuild. Original error: ${message}`,
  30 |     )
  31 |   }
  32 | 
  33 |   return error instanceof Error ? error : new Error(message)
  34 | }
  35 | 
  36 | const getWxCloudRuntime = (): WxCloudRuntime => {
  37 |   if (typeof wx === 'undefined' || !wx.cloud) {
  38 |     throw new Error('CloudBase runtime is only available inside WeChat Mini Program')
  39 |   }
  40 | 
  41 |   if (!initialized) {
  42 |     wx.cloud.init?.({ env: cloudBaseEnvId })
  43 |     initialized = true
  44 |   }
  45 | 
  46 |   return wx.cloud
  47 | }
  48 | 
  49 | export const getRuntimeCloudBaseMallApiClient = (): CloudBaseMallApiClient => {
  50 |   if (!client) {
  51 |     client = createCloudBaseMallApiClient(
  52 |       createCloudBaseFunctionClient({
  53 |         async callFunction(request) {
  54 |           try {
  55 |             return await getWxCloudRuntime().callFunction(request)
  56 |           } catch (error) {
  57 |             throw createRuntimeCloudBaseError(error)
  58 |           }
  59 |         },
  60 |       }),
  61 |     )
  62 |   }
  63 | 
  64 |   return client
  65 | }
  66 | 
```

**src/services/auth/mock-wechat-auth-service.ts:1-70**

```
   1 | import { nowIso } from '../../domain/shared/ids'
   2 | import type { CustomerSession } from './customer-session'
   3 | import type { WechatAuthService } from './wechat-auth-service'
   4 | 
   5 | let currentSession: CustomerSession | null = null
   6 | 
   7 | const copySession = (session: CustomerSession): CustomerSession => ({ ...session })
   8 | 
   9 | export const mockWechatAuthService: WechatAuthService = {
  10 |   getCurrentSession() {
  11 |     return currentSession ? copySession(currentSession) : null
  12 |   },
  13 |   async login() {
  14 |     currentSession = {
  15 |       customerId: 'mock-customer-001',
  16 |       openid: 'mock-openid-001',
  17 |       nickname: '微信用户',
  18 |       authSource: 'mock_wechat',
  19 |       loggedInAt: nowIso(),
  20 |     }
  21 | 
  22 |     return copySession(currentSession)
  23 |   },
  24 |   async authorizePhoneNumber(phoneNumber?: string) {
  25 |     if (!currentSession) {
  26 |       return null
  27 |     }
  28 | 
  29 |     currentSession = {
  30 |       ...currentSession,
  31 |       phoneNumber: phoneNumber ?? '[REDACTED_PHONE]',
  32 |       phoneAuthorizedAt: nowIso(),
  33 |     }
  34 | 
  35 |     return copySession(currentSession)
  36 |   },
  37 |   logout() {
  38 |     currentSession = null
  39 |   },
  40 | }
  41 | 
```

### 21. Image upload interface

**src/services/storage/upload-service.ts:1-50**

```
   1 | export type UploadBusinessType = 'ocr_screenshot' | 'product_main_image' | 'product_detail_image'
   2 | 
   3 | export type UploadSourceRole = 'owner' | 'staff'
   4 | 
   5 | export type UploadEntityType = 'ocr_batch' | 'product'
   6 | 
   7 | export type UploadContext = {
   8 |   businessType: UploadBusinessType
   9 |   sourceRole: UploadSourceRole
  10 |   entityType: UploadEntityType
  11 |   entityId?: string
  12 |   count?: number
  13 | }
  14 | 
  15 | export type UploadFailureCode =
  16 |   | 'file_too_large'
  17 |   | 'unsupported_format'
  18 |   | 'network_failed'
  19 |   | 'server_failed'
  20 |   | 'security_review_failed'
  21 | 
  22 | export type UploadAssetStatus = 'uploaded' | 'pending_review' | 'failed' | 'deleted' | 'replaced'
  23 | 
  24 | export type UploadedAsset = {
  25 |   assetId: string
  26 |   url: string
  27 |   mimeType: string
  28 |   size: number
  29 |   checksum: string
  30 |   status: UploadAssetStatus
  31 |   cloudPath?: string
  32 |   expiresAt?: string
  33 |   failureCode?: UploadFailureCode
  34 | }
  35 | 
  36 | export type UploadResult = {
  37 |   mainImageUrl: string
  38 |   imageUrls: string[]
  39 |   assets: UploadedAsset[]
  40 | }
  41 | 
  42 | export type UploadedImage = {
  43 |   id: string
  44 |   url: string
  45 |   name: string
  46 |   assetId?: string
  47 | }
  48 | 
  49 | export type DeleteUploadResult = {
  50 |   deletedAssetIds: string[]
```

**src/services/storage/cloudbase-upload-service.ts:1-80**

```
   1 | import { createId } from '../../domain/shared/ids'
   2 | import type {
   3 |   DeleteUploadResult,
   4 |   UploadAssetStatus,
   5 |   UploadContext,
   6 |   UploadedAsset,
   7 |   UploadFailureCode,
   8 |   UploadResult,
   9 |   UploadService,
  10 |   UploadedImage,
  11 | } from './upload-service'
  12 | 
  13 | type WxCloudRuntime = {
  14 |   init?: (options: { env: string }) => void
  15 |   uploadFile: (request: { cloudPath: string; filePath: string }) => Promise<{ fileID: string }>
  16 |   getTempFileURL: (request: { fileList: Array<{ fileID: string; maxAge?: number }> }) => Promise<{
  17 |     fileList: Array<{ fileID: string; tempFileURL?: string; download_url?: string }>
  18 |   }>
  19 |   deleteFile: (request: { fileList: string[] }) => Promise<{ fileList: Array<{ fileID: string; status: string }> }>
  20 |   getFileInfo?: (request: { fileList: string[]; type?: 'image' }) => Promise<{
  21 |     fileList: Array<{ fileID: string; size: number; digest?: string }>
  22 |   }>
  23 |   compressImage?: (request: { src: string; quality?: number }) => Promise<{ tempFilePath: string }>
  24 | }
  25 | 
  26 | type UniRuntime = {
  27 |   chooseImage?: (options: {
  28 |     count?: number
  29 |     success?: (result: { tempFilePaths: string[] | string; tempFiles?: Array<{ path: string; size: number }> }) => void
  30 |     fail?: (error: unknown) => void
  31 |   }) => void
  32 |   getImageInfo?: (options: {
  33 |     src: string
  34 |     success?: (result: { width: number; height: number; type: string; orientation: string; path?: string }) => void
  35 |     fail?: (error: unknown) => void
  36 |   }) => void
  37 |   compressImage?: (options: {
  38 |     src: string
  39 |     quality?: number
  40 |     success?: (result: { tempFilePath: string }) => void
  41 |     fail?: (error: unknown) => void
  42 |   }) => void
  43 | }
  44 | 
  45 | declare const wx: { cloud?: WxCloudRuntime } | undefined
  46 | declare const uni: UniRuntime | undefined
  47 | 
  48 | const cloudBaseEnvId = '[REDACTED_CLOUDBASE_ENV]'
  49 | const maxFileSizeBytes = 8 * 1024 * 1024
  50 | const supportedExtensions = ['.png', '.jpg', '.jpeg', '.webp']
  51 | const tempFileUrlMaxAgeSeconds = 45 * 60
  52 | 
  53 | let initialized = false
  54 | 
  55 | const ensureRuntime = (): WxCloudRuntime => {
  56 |   if (typeof wx === 'undefined' || !wx.cloud) {
  57 |     throw new Error('CloudBase storage runtime is only available inside WeChat Mini Program')
  58 |   }
  59 | 
  60 |   if (!initialized) {
  61 |     wx.cloud.init?.({ env: cloudBaseEnvId })
  62 |     initialized = true
  63 |   }
  64 | 
  65 |   return wx.cloud
  66 | }
  67 | 
  68 | const inferMimeType = (filePath: string): string => {
  69 |   const lower = filePath.toLowerCase()
  70 |   if (lower.endsWith('.png')) return 'image/png'
  71 |   if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg'
  72 |   if (lower.endsWith('.webp')) return 'image/webp'
  73 |   return 'application/octet-stream'
  74 | }
  75 | 
  76 | const fileNameFromPath = (filePath: string, index: number): string => {
  77 |   const trimmed = filePath.split('?')[0]
  78 |   return trimmed.split('/').pop() || `upload-${index + 1}.png`
  79 | }
  80 | 
```

### 22. OCR provider interface

**src/services/ocr/ocr-provider.ts:1-50**

```
   1 | import type { UploadedImage } from '../../domain/batch/types'
   2 | import type { ProductDraft } from '../../domain/draft/types'
   3 | 
   4 | export type OcrProviderInput = {
   5 |   batchId: string
   6 |   images: UploadedImage[]
   7 |   context: {
   8 |     jobId: string
   9 |     requestedAt: string
  10 |   }
  11 | }
  12 | 
  13 | export type OcrProviderErrorCode = 'timeout' | 'rate_limited' | 'service_error' | 'invalid_response' | 'configuration_error'
  14 | 
  15 | export type OcrProviderError = {
  16 |   code: OcrProviderErrorCode
  17 |   message: string
  18 |   recoverable: true
  19 | }
  20 | 
  21 | export type OcrProviderResult =
  22 |   | { ok: true; drafts: ProductDraft[] }
  23 |   | { ok: false; error: OcrProviderError }
  24 | 
  25 | export interface OcrProvider {
  26 |   recognizeBatch(input: OcrProviderInput): Promise<OcrProviderResult>
  27 | }
  28 | 
```

**src/services/ocr/tencentcloud-ocr-provider.ts:1-90**

```
   1 | import * as tencentcloud from 'tencentcloud-sdk-nodejs'
   2 | import { markDraftCompletion } from '../../domain/draft/rules'
   3 | import type { ProductDraft } from '../../domain/draft/types'
   4 | import { createId } from '../../domain/shared/ids'
   5 | import type { OcrProvider, OcrProviderErrorCode, OcrProviderInput, OcrProviderResult } from './ocr-provider'
   6 | 
   7 | type TencentCloudTextDetection = {
   8 |   DetectedText?: string
   9 |   Confidence?: number
  10 | }
  11 | 
  12 | type TencentCloudGeneralBasicOCRResponse = {
  13 |   TextDetections?: TencentCloudTextDetection[]
  14 | }
  15 | 
  16 | export type TencentCloudOcrClient = {
  17 |   GeneralBasicOCR: (request: { ImageUrl: string }) => Promise<TencentCloudGeneralBasicOCRResponse | { Response?: TencentCloudGeneralBasicOCRResponse }>
  18 | }
  19 | 
  20 | export type TencentCloudOcrProviderConfig = {
  21 |   endpoint: string
  22 |   secretId: string
  23 |   secretKey: string
  24 |   region?: string
  25 |   timeoutMs?: number
  26 |   client?: TencentCloudOcrClient
  27 |   resolveImageUrl?: (assetId: string) => Promise<string> | string
  28 | }
  29 | 
  30 | type ParsedTextField = {
  31 |   value: string
  32 |   confidence: number
  33 | }
  34 | 
  35 | const DEFAULT_REGION = 'ap-guangzhou'
  36 | 
  37 | const errorResult = (code: OcrProviderErrorCode, message: string): OcrProviderResult => ({
  38 |   ok: false,
  39 |   error: {
  40 |     code,
  41 |     message,
  42 |     recoverable: true,
  43 |   },
  44 | })
  45 | 
  46 | const normalizeConfidence = (confidence: unknown): number => {
  47 |   if (typeof confidence !== 'number' || !Number.isFinite(confidence)) return 0
  48 |   return Math.min(1, Math.max(0, confidence > 1 ? confidence / 100 : confidence))
  49 | }
  50 | 
  51 | const readDetectedText = (value: unknown): string => (typeof value === 'string' ? value.trim() : '')
  52 | 
  53 | const escapeRegExp = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  54 | 
  55 | const parseTextField = (lines: Array<{ text: string; confidence: number }>, labels: string[]): ParsedTextField => {
  56 |   for (let index = 0; index < lines.length; index += 1) {
  57 |     const currentLine = lines[index]
  58 |     for (const label of labels) {
  59 |       const pattern = new RegExp(`^${escapeRegExp(label)}\\s*[:：]?\\s*(.+)$`, 'i')
  60 |       const match = currentLine.text.match(pattern)
  61 |       if (match?.[1]) return { value: match[1].trim(), confidence: currentLine.confidence }
  62 | 
  63 |       const nextLine = lines[index + 1]
  64 |       if (currentLine.text === label && nextLine?.text && !labels.includes(nextLine.text)) {
  65 |         return {
  66 |           value: nextLine.text.trim(),
  67 |           confidence: Math.min(currentLine.confidence || 0, nextLine.confidence || 0) || currentLine.confidence,
  68 |         }
  69 |       }
  70 |     }
  71 |   }
  72 |   return { value: '', confidence: 0 }
  73 | }
  74 | 
  75 | const parseSalePrice = (value: string) => {
  76 |   const match = value.match(/\d+(?:\.\d+)?/)
  77 |   return match ? Number(match[0]) : 0
  78 | }
  79 | 
  80 | const textDetectionsToDraft = (batchId: string, imageUrl: string, detections: TencentCloudTextDetection[]): ProductDraft => {
  81 |   const lines = detections
  82 |     .map((item) => ({
  83 |       text: readDetectedText(item.DetectedText),
  84 |       confidence: normalizeConfidence(item.Confidence),
  85 |     }))
  86 |     .filter((line): line is { text: string; confidence: number } => Boolean(line.text))
  87 | 
  88 |   const productCode = parseTextField(lines, ['货号', '商品货号', '款号', 'productCode', 'product_code'])
  89 |   const productName = parseTextField(lines, ['商品名称', '品名', '名称', 'productName', 'product_name'])
  90 |   const salePrice = parseTextField(lines, ['销售价', '售价', '价格', 'productPrice', 'salePrice', 'sale_price'])
```

### 23. Repository port and implementations

**src/services/repositories/mall-repository-port.ts:1-120**

```
   1 | import type { OcrBatch, OcrJob } from '../../domain/batch/types'
   2 | import type { Product, Sku } from '../../domain/catalog/types'
   3 | import type { ProductDraft } from '../../domain/draft/types'
   4 | import type { InventoryLedgerEntry } from '../../domain/inventory/types'
   5 | import type { Order } from '../../domain/order/types'
   6 | 
   7 | export type RepositoryResult<T> = T | Promise<T>
   8 | 
   9 | export type MallRepositoryContract = {
  10 |   saveBatch: (batch: OcrBatch) => RepositoryResult<OcrBatch>
  11 |   updateBatch: (batch: OcrBatch) => RepositoryResult<OcrBatch>
  12 |   listBatches: () => RepositoryResult<OcrBatch[]>
  13 |   saveOcrJob: (job: OcrJob) => RepositoryResult<OcrJob>
  14 |   updateOcrJob: (job: OcrJob) => RepositoryResult<OcrJob>
  15 |   listOcrJobs: (batchId?: string) => RepositoryResult<OcrJob[]>
  16 |   saveDrafts: (drafts: ProductDraft[]) => RepositoryResult<ProductDraft[]>
  17 |   replaceDrafts: (batchId: string, drafts: ProductDraft[]) => RepositoryResult<ProductDraft[]>
  18 |   listDrafts: (batchId?: string) => RepositoryResult<ProductDraft[]>
  19 |   saveProducts: (products: Product[], skus: Sku[]) => RepositoryResult<{ products: Product[]; skus: Sku[] }>
  20 |   updateProduct: (product: Product) => RepositoryResult<Product>
  21 |   deleteProduct: (productId: string) => RepositoryResult<Product | null>
  22 |   deleteSkus: (productId: string) => RepositoryResult<Sku[]>
  23 |   listProducts: () => RepositoryResult<Product[]>
  24 |   listSkus: (productId?: string) => RepositoryResult<Sku[]>
  25 |   updateSku: (sku: Sku) => RepositoryResult<Sku>
  26 |   saveOrder: (order: Order) => RepositoryResult<Order>
  27 |   updateOrder: (order: Order) => RepositoryResult<Order>
  28 |   listOrders: () => RepositoryResult<Order[]>
  29 |   saveInventoryLedgerEntry: (entry: InventoryLedgerEntry) => RepositoryResult<InventoryLedgerEntry>
  30 |   listInventoryLedgerEntries: (skuId?: string) => RepositoryResult<InventoryLedgerEntry[]>
  31 | }
  32 | 
  33 | export type MallRepository = {
  34 |   saveBatch: (batch: OcrBatch) => OcrBatch
  35 |   updateBatch: (batch: OcrBatch) => OcrBatch
  36 |   listBatches: () => OcrBatch[]
  37 |   saveOcrJob: (job: OcrJob) => OcrJob
  38 |   updateOcrJob: (job: OcrJob) => OcrJob
  39 |   listOcrJobs: (batchId?: string) => OcrJob[]
  40 |   saveDrafts: (drafts: ProductDraft[]) => ProductDraft[]
  41 |   replaceDrafts: (batchId: string, drafts: ProductDraft[]) => ProductDraft[]
  42 |   listDrafts: (batchId?: string) => ProductDraft[]
  43 |   saveProducts: (products: Product[], skus: Sku[]) => { products: Product[]; skus: Sku[] }
  44 |   updateProduct: (product: Product) => Product
  45 |   deleteProduct: (productId: string) => Product | null
  46 |   deleteSkus: (productId: string) => Sku[]
  47 |   listProducts: () => Product[]
  48 |   listSkus: (productId?: string) => Sku[]
  49 |   updateSku: (sku: Sku) => Sku
  50 |   saveOrder: (order: Order) => Order
  51 |   updateOrder: (order: Order) => Order
  52 |   listOrders: () => Order[]
  53 |   saveInventoryLedgerEntry: (entry: InventoryLedgerEntry) => InventoryLedgerEntry
  54 |   listInventoryLedgerEntries: (skuId?: string) => InventoryLedgerEntry[]
  55 | }
  56 | 
```

**src/services/repositories/memory-mall-repository.ts:1-100**

```
   1 | import type { MallRepository } from './mall-repository-port'
   2 | import { mockDb, type MockDb } from './mock-db'
   3 | 
   4 | export const createMemoryMallRepository = (database: MockDb = mockDb): MallRepository => ({
   5 |   saveBatch(batch) {
   6 |     database.batches = [...database.batches, batch]
   7 |     return batch
   8 |   },
   9 |   updateBatch(batch) {
  10 |     database.batches = database.batches.map((item) => (item.id === batch.id ? batch : item))
  11 |     return batch
  12 |   },
  13 |   listBatches() {
  14 |     return [...database.batches]
  15 |   },
  16 |   saveOcrJob(job) {
  17 |     database.ocrJobs = [...database.ocrJobs, job]
  18 |     return job
  19 |   },
  20 |   updateOcrJob(job) {
  21 |     database.ocrJobs = database.ocrJobs.map((item) => (item.id === job.id ? job : item))
  22 |     return job
  23 |   },
  24 |   listOcrJobs(batchId) {
  25 |     return batchId ? database.ocrJobs.filter((job) => job.batchId === batchId) : [...database.ocrJobs]
  26 |   },
  27 |   saveDrafts(drafts) {
  28 |     database.drafts = [...database.drafts, ...drafts]
  29 |     return drafts
  30 |   },
  31 |   replaceDrafts(batchId, drafts) {
  32 |     database.drafts = [...database.drafts.filter((draft) => draft.batchId !== batchId), ...drafts]
  33 |     return drafts
  34 |   },
  35 |   listDrafts(batchId) {
  36 |     return batchId ? database.drafts.filter((draft) => draft.batchId === batchId) : [...database.drafts]
  37 |   },
  38 |   saveProducts(products, skus) {
  39 |     database.products = [...database.products, ...products]
  40 |     database.skus = [...database.skus, ...skus]
  41 |     return { products, skus }
  42 |   },
  43 |   updateProduct(product) {
  44 |     database.products = database.products.map((item) => (item.id === product.id ? product : item))
  45 |     return product
  46 |   },
  47 |   deleteProduct(productId) {
  48 |     const product = database.products.find((item) => item.id === productId) ?? null
  49 |     database.products = database.products.filter((item) => item.id !== productId)
  50 |     return product
  51 |   },
  52 |   deleteSkus(productId) {
  53 |     const skus = database.skus.filter((sku) => sku.productId === productId)
  54 |     database.skus = database.skus.filter((sku) => sku.productId !== productId)
  55 |     return skus
  56 |   },
  57 |   listProducts() {
  58 |     return [...database.products]
  59 |   },
  60 |   listSkus(productId) {
  61 |     return productId ? database.skus.filter((sku) => sku.productId === productId) : [...database.skus]
  62 |   },
  63 |   updateSku(sku) {
  64 |     database.skus = database.skus.map((item) => (item.id === sku.id ? sku : item))
  65 |     return sku
  66 |   },
  67 |   saveOrder(order) {
  68 |     database.orders = [...database.orders, order]
  69 |     return order
  70 |   },
  71 |   updateOrder(order) {
  72 |     database.orders = database.orders.map((item) => (item.id === order.id ? order : item))
  73 |     return order
  74 |   },
  75 |   listOrders() {
  76 |     return [...database.orders]
  77 |   },
  78 |   saveInventoryLedgerEntry(entry) {
  79 |     database.inventoryLedger = [...database.inventoryLedger, entry]
  80 |     return entry
  81 |   },
  82 |   listInventoryLedgerEntries(skuId) {
  83 |     return skuId ? database.inventoryLedger.filter((entry) => entry.skuId === skuId) : [...database.inventoryLedger]
  84 |   },
  85 | })
  86 | 
  87 | export const memoryMallRepository = createMemoryMallRepository()
  88 | 
```

### 24. Error handling

**backend/src/api/errors.ts:1-80**

```
   1 | import { backendErrorCodes, type BackendErrorCode } from '../http/errors'
   2 | 
   3 | export class ApiError extends Error {
   4 |   constructor(
   5 |     readonly statusCode: number,
   6 |     readonly code: BackendErrorCode,
   7 |     message: string,
   8 |   ) {
   9 |     super(message)
  10 |   }
  11 | }
  12 | 
  13 | export const validationError = (message: string): ApiError =>
  14 |   new ApiError(400, backendErrorCodes.VALIDATION_ERROR, message)
  15 | 
  16 | export const unauthorizedError = (message: string): ApiError =>
  17 |   new ApiError(401, backendErrorCodes.UNAUTHORIZED, message)
  18 | 
  19 | export const notFoundError = (message: string): ApiError => new ApiError(404, backendErrorCodes.NOT_FOUND, message)
  20 | 
  21 | export const conflictError = (message: string): ApiError => new ApiError(409, backendErrorCodes.CONFLICT, message)
  22 | 
```

**backend/src/api/handlers/mall-api.ts:127-145**

```
 127 |     createdAt: string
 128 |   }) => Promise<unknown>
 129 | }
 130 | 
 131 | export type MallApiContext = {
 132 |   repository: MallApiRepository
 133 |   createId: (prefix: string) => string
 134 |   now: () => string
 135 | }
 136 | 
 137 | type RouteRequest = {
 138 |   method?: string
 139 |   body: unknown
 140 |   params: Record<string, string>
 141 |   response: Parameters<typeof sendJson>[0]
 142 | }
 143 | 
 144 | type RouteHandler = (request: RouteRequest, context: MallApiContext) => Promise<void>
 145 | 
```

### 25. Audit log / inventory ledger

**backend/src/api/handlers/mall-api.ts:108-124**

```
 108 |   replaceDrafts: (batchId: string, drafts: ProductDraft[]) => Promise<ProductDraft[]>
 109 |   listDrafts: (batchId?: string) => Promise<ProductDraft[]>
 110 |   saveProducts: (products: Product[], skus: Sku[]) => Promise<{ products: Product[]; skus: Sku[] }>
 111 |   updateProduct: (product: Product) => Promise<Product>
 112 |   listProducts: () => Promise<Product[]>
 113 |   listSkus: (productId?: string) => Promise<Sku[]>
 114 |   updateSku: (sku: Sku) => Promise<Sku>
 115 |   saveOrder: (order: Order) => Promise<Order>
 116 |   updateOrder: (order: Order) => Promise<Order>
 117 |   listOrders: () => Promise<Order[]>
 118 |   saveInventoryLedgerEntry: (entry: {
 119 |     id: string
 120 |     skuId: string
 121 |     orderId?: string
 122 |     action: 'reserve' | 'release' | 'confirm' | 'adjust'
 123 |     quantityDelta: number
 124 |     sourceType: 'order' | 'manual'
```

**backend/src/repositories/database-mall-repository.ts:732-760**

```
 732 |   async saveInventoryLedgerEntry(entry: InventoryLedgerEntry): Promise<InventoryLedgerEntry> {
 733 |     return insertInventoryLedgerEntry(database, entry)
 734 |   },
 735 | 
 736 |   async listInventoryLedgerEntries(skuId?: string): Promise<InventoryLedgerEntry[]> {
 737 |     const { rows } = skuId
 738 |       ? await database.query<InventoryLedgerRow>('SELECT * FROM inventory_ledger WHERE sku_id = $1 ORDER BY created_at, id', [skuId])
 739 |       : await database.query<InventoryLedgerRow>('SELECT * FROM inventory_ledger ORDER BY created_at, id')
 740 | 
 741 |     return rows.map(toInventoryLedgerEntry)
 742 |   },
 743 | })
 744 | type InventoryLedgerEntry = {
 745 |   id: string
 746 |   skuId: string
 747 |   orderId?: string
 748 |   action: 'reserve' | 'release' | 'confirm' | 'adjust'
 749 |   quantityDelta: number
 750 |   sourceType: 'order' | 'manual'
 751 |   sourceId: string
 752 |   note: string
 753 |   createdAt: string
 754 | }
 755 | 
 756 | type InventoryLedgerRow = {
 757 |   id: string
 758 |   sku_id: string
 759 |   order_id: string | null
 760 |   action: InventoryLedgerEntry['action']
```